import axios from 'axios';

// The URL now points to the DIRECTORY.
const API_BASE_URL = 'http://localhost/glow_ecommerce/backend/api/';

const api = axios.create({
  baseURL: API_BASE_URL,
});

api.defaults.withCredentials = true;

// NEW URL STRUCTURE: We now call index.php directly with parameters.
// This is the most reliable way for local development.
export const getProducts = (params) => api.get('index.php', { params: { endpoint: 'products', ...params } });
export const getCategories = () => api.get('index.php', { params: { endpoint: 'categories' } });

// For POST requests, the endpoint is in the URL, and the data is the second argument.
export const createOrder = (orderData) => api.post('index.php?endpoint=create-order', orderData);
export const verifyPayment = (paymentData) => api.post('index.php?endpoint=verify-payment', paymentData);

export default api;