import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { ShoppingBag } from 'lucide-react';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault(); // Prevent navigation when clicking the buy button
    addToCart(product, 1, 0); // Add 1 item, with the first color selected
  };

  return (
    <Link to={`/product/${product.id}`} className="group">
        <div className="bg-gray-100 rounded-lg overflow-hidden aspect-w-1 aspect-h-1">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
        </div>
        <div className="pt-4">
            <div className="flex justify-between items-start mb-1">
                <h3 className="font-semibold text-sm text-primary pr-2">{product.name}</h3>
                <span className="text-accent font-bold">${product.price.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-gray-500">
                <div className="flex items-center space-x-1">
                    {product.colors?.slice(0, 3).map((color, index) => (
                        <div
                            key={index}
                            className="w-4 h-4 rounded-full border"
                            style={{ backgroundColor: color }}
                        />
                    ))}
                </div>
                <button
                    onClick={handleAddToCart}
                    className="bg-accent text-white px-3 py-1 rounded-full text-sm font-semibold hover:bg-pink-500 transition-colors"
                >
                    Buy
                </button>
            </div>
        </div>
    </Link>
  );
};

export default ProductCard;