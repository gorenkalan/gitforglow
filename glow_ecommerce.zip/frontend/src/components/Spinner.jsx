import React from 'react';

const Spinner = () => {
  return <div className="spinner" />;
};

export default Spinner;