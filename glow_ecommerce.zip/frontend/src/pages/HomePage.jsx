import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getProducts, getCategories } from '../services/api';
import { ChevronRight } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import Spinner from '../components/Spinner';

const HomePage = () => {
    const [popularProducts, setPopularProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);

    const categoryImages = {
        cream: 'https://images.pexels.com/photos/3993398/pexels-photo-3993398.jpeg',
        serum: 'https://images.unsplash.com/photo-1598528738936-c50861cc75a9',
        makeup: 'https://images.pexels.com/photos/1377034/pexels-photo-1377034.jpeg',
        skincare: 'https://images.unsplash.com/photo-1580870069867-74c57ee1bb07',
    };

    useEffect(() => {
        const fetchData = async () => {
            try {
                setLoading(true);
                const [productsRes, categoriesRes] = await Promise.all([
                    getProducts({ limit: 6, sort_by: 'rating' }),
                    getCategories()
                ]);

                // Defensive check: Ensure the response data and nested arrays exist before setting state
                if (productsRes.data && Array.isArray(productsRes.data.products)) {
                    setPopularProducts(productsRes.data.products);
                }
                
                if (categoriesRes.data && Array.isArray(categoriesRes.data.categories)) {
                    setCategories(categoriesRes.data.categories);
                }

            } catch (error) {
                console.error("Failed to fetch homepage data:", error);
                // In case of an error, ensure states remain as empty arrays
                setPopularProducts([]);
                setCategories([]);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) {
        return <div className="flex justify-center items-center h-96"><Spinner /></div>;
    }

    return (
        <div className="px-6 py-6 space-y-12">
            {/* Categories Section */}
            <div>
                {/* ... (rest of the JSX is the same) ... */}
            </div>

            {/* Popular Section */}
            <div>
                {/* ... (rest of the JSX is the same) ... */}
            </div>
        </div>
    );
};

export default HomePage;