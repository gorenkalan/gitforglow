<?php
// This script assumes it's included by a file that has already started the session and authenticated the user.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo "Unauthorized";
    exit;
}

require_once __DIR__ . '/../vendor/autoload.php';
use App\GoogleSheetsService;

// This function now lives here, as it's the core of the cache building process.
function build_products_cache() {
    $sheetsService = new GoogleSheetsService();
    $products = $sheetsService->getSheetData(App\Config::get('GOOGLE_SHEET_NAME_PRODUCTS'));
    $inventory = $sheetsService->getSheetData(App\Config::get('GOOGLE_SHEET_NAME_INVENTORY'));

    $inventoryByProductId = [];
    foreach ($inventory as $item) {
        $productId = $item['productId'];
        if (!isset($inventoryByProductId[$productId])) {
            $inventoryByProductId[$productId] = [];
        }
        $inventoryByProductId[$productId][] = [
            'variationId' => $item['variationId'],
            'colorName' => $item['colorName'],
            'colorHex' => $item['colorHex'],
            'imageUrl' => $item['imageUrl'],
        ];
    }

    $combined = [];
    foreach ($products as $product) {
        $productId = $product['id'];
        $variations = $inventoryByProductId[$productId] ?? [];
        
        if (!empty($variations)) {
             $combined[] = [
                'id' => $productId,
                'name' => $product['name'] ?? 'No Name',
                'basePrice' => isset($product['basePrice']) ? (float)$product['basePrice'] : 0,
                'description' => $product['description'] ?? '',
                'category' => $product['category'] ?? 'Uncategorized',
                'tags' => isset($product['tags']) ? array_map('trim', explode(',', $product['tags'])) : [],
                'rating' => isset($product['rating']) ? (float)$product['rating'] : 0,
                'reviews' => isset($product['reviews']) ? (int)$product['reviews'] : 0,
                'variations' => $variations,
            ];
        }
    }
    
    // Write to the cache file
    $cacheDir = __DIR__ . '/../cache/';
    if (!is_dir($cacheDir)) {
        mkdir($cacheDir, 0775, true);
    }
    file_put_contents($cacheDir . 'products.json', json_encode($combined, JSON_PRETTY_PRINT));
}

// Execute the cache build
build_products_cache();

// This script will be called from admin/index.php, so the success message logic remains there.